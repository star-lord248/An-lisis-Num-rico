function x = my_gauss_seidel_alvaro_martinez(A, b, x0, tolerance)
% my_gauss_seidel_name_lastname
% Resuelve el sistema Ax = b usando el método de Gauss-Seidel.
% Asegura que la matriz A sea diagonalmente dominante.
%
% Entradas:
%   A         - matriz de coeficientes (n x n)
%   b         - vector del lado derecho (n x 1)
%   x0        - vector inicial (n x 1)
%   tolerance - criterio de parada (ej. 1e-6)
%
% Salida:
%   x         - vector solución

    % Verificar que A sea cuadrada
    [n, m] = size(A);
    if n ~= m
        error('La matriz A debe ser cuadrada.');
    end

    % Intentar asegurar dominancia diagonal
    [A, msg] = make_diagonally_dominant(A);
    disp(msg)

    % Inicialización
    x = x0;
    max_iter = 1000;

    % Iteraciones de Gauss-Seidel
    for k = 1:max_iter
        x_old = x;  % Guardamos la iteración anterior

        for i = 1:n
            sum1 = A(i, 1:i-1) * x(1:i-1);
            sum2 = A(i, i+1:n) * x_old(i+1:n);
            x(i) = (b(i) - sum1 - sum2) / A(i, i);
        end

        % Criterio de parada
        if norm(x - x_old, inf) < tolerance
            fprintf('Convergencia alcanzada en %d iteraciones.\n', k);
            return;
        end
    end

    warning('No se alcanzó la convergencia después de %d iteraciones.', max_iter);
end


%% --- Función auxiliar para verificar/ajustar dominancia diagonal ---
function [A, str] = make_diagonally_dominant(A)
    [n, ~] = size(A);
    if is_diagonally_dominant(A)
        str = 'La matriz ya es diagonalmente dominante.';
        return;
    end

    permsIdx = perms(1:n);
    for i = 1:size(permsIdx, 1)
        B = A(permsIdx(i, :), :);
        if is_diagonally_dominant(B)
            A = B;
            str = 'La matriz fue permutada para ser diagonalmente dominante.';
            return;
        end
    end

    str = 'No se pudo lograr la dominancia diagonal.';
end


%% --- Función auxiliar para verificar dominancia ---
function flag = is_diagonally_dominant(M)
    n = size(M, 1);
    flag = true;
    for i = 1:n
        diagElem = abs(M(i, i));
        offDiagSum = sum(abs(M(i, :))) - diagElem;
        if diagElem < offDiagSum
            flag = false;
            return;
        end
    end
end
