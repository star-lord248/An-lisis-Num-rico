function [L, U, P] = my_lu_alvaro_martinez(A)
% MY_LU_ALVARO_MARTINEZ realiza la factorización LU con pivoteo parcial.
% Entradas:
%   A -> matriz cuadrada
% Salidas:
%   L -> matriz triangular inferior
%   U -> matriz triangular superior
%   P -> matriz de permutación

[n, m] = size(A);
if n ~= m
    error('La matriz debe ser cuadrada');
end

P = eye(n);
L = eye(n);
U = A;

for k = 1:n-1
    % Pivoteo parcial
    [~, idx] = max(abs(U(k:n, k)));
    idx = idx + k - 1;
    if idx ~= k
        % Intercambiar filas en U
        U([k idx], :) = U([idx k], :);
        % Intercambiar filas en P
        P([k idx], :) = P([idx k], :);
        % Intercambiar filas en L (solo columnas 1:k-1)
        if k > 1
            L([k idx], 1:k-1) = L([idx k], 1:k-1);
        end
    end

    % Eliminación
    for i = k+1:n
        L(i,k) = U(i,k) / U(k,k);
        U(i,:) = U(i,:) - L(i,k)*U(k,:);
    end
end
end