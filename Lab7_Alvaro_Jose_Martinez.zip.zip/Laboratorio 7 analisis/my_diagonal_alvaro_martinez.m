function [A, str] = my_diagonal_alvaro_martinez(A)
% my_diagonal_name_lastname
% Verifica si una matriz A cumple con la dominancia diagonal.
% Si no cumple, intenta modificarla intercambiando filas.
%
% Entradas:
%   A - matriz cuadrada
%
% Salidas:
%   A - matriz (posiblemente modificada)
%   str - mensaje indicando si se logró la dominancia

    % Verificamos que la matriz sea cuadrada
    [n, m] = size(A);
    if n ~= m
        error('La matriz debe ser cuadrada.');
    end

    % --- Paso 1: Comprobar si ya es diagonalmente dominante ---
    if is_diagonally_dominant(A)
        str = 'La matriz ya es diagonalmente dominante.';
        return;
    end

    % --- Paso 2: Intentar permutar filas para lograr dominancia ---
    permsIdx = perms(1:n);  % Todas las permutaciones posibles de filas
    for i = 1:size(permsIdx, 1)
        B = A(permsIdx(i, :), :);
        if is_diagonally_dominant(B)
            A = B;
            str = 'Se logró la dominancia diagonal permutando filas.';
            return;
        end
    end

    % --- Si no se logra ---
    str = 'No fue posible lograr la dominancia diagonal.';
end


% --- Función auxiliar ---
function flag = is_diagonally_dominant(M)
    n = size(M, 1);
    flag = true;
    for i = 1:n
        diagElem = abs(M(i, i));
        offDiagSum = sum(abs(M(i, :))) - diagElem;
        if diagElem < offDiagSum
            flag = false;
            return;
        end
    end
end