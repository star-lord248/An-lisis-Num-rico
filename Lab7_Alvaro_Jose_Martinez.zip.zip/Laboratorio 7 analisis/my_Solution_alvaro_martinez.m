function [x] = my_Solution_alvaro_martinez(L, U, P, b)
% MY_SOLUTION_ALVARO_MARTINEZ resuelve el sistema Ax = b 
% utilizando la factorización LU.
%
% Entradas:
%   L -> matriz triangular inferior
%   U -> matriz triangular superior
%   P -> matriz de permutación
%   b -> vector columna del sistema
%
% Salida:
%   x -> vector solución

% Paso 1: aplicar permutación a b
Pb = P * b;

% Paso 2: resolver L*y = Pb  (sustitución hacia adelante)
n = length(b);
y = zeros(n,1);
for i = 1:n
    y(i) = Pb(i) - L(i,1:i-1) * y(1:i-1);
end

% Paso 3: resolver U*x = y  (sustitución hacia atrás)
x = zeros(n,1);
for i = n:-1:1
    x(i) = (y(i) - U(i,i+1:n) * x(i+1:n)) / U(i,i);
end
end