function Verification_fixed_point_function_name_lastname(g, p0, a, b)
% Verification_fixed_point_function_name_lastname
% Verifica si una función g(x) tiene punto fijo en [a,b] y si el método converge.
%
% Entradas:
%   g  -> function handle, ej. @(x) 1 - (x.^3)/4
%   p0 -> punto inicial (no se usa mucho aquí, solo de referencia)
%   a  -> límite inferior del intervalo
%   b  -> límite superior del intervalo
%
% Salida: imprime en pantalla uno de los 3 mensajes:
%   'It has a fixed point.'
%   'The fixed point converges and its unique.'
%   'It has no fixed point.'

    syms x
    g_sym = g(x);         % función simbólica
    dg    = diff(g_sym);  % derivada

    % Evaluar condiciones en el intervalo
    ga = g(a); 
    gb = g(b);

    % Comprobar si g(x) está dentro de [a,b]
    if ga < a || ga > b || gb < a || gb > b
        disp('It has no fixed point.');
        return;
    end

    % Verificar condición de convergencia |g'(x)| < 1 en todo [a,b]
    fhandle_dg = matlabFunction(dg);   % convertir derivada a función
    N = 1000;                          % muestreo de puntos en [a,b]
    X = linspace(a,b,N);
    dvals = abs(fhandle_dg(X));

    if all(dvals < 1)
        disp('The fixed point converges and its unique.');
    else
        disp('It has a fixed point.');
    end
end