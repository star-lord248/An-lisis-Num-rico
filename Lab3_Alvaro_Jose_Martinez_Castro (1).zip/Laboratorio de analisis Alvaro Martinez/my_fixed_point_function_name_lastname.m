function P = my_fixed_point_function_name_lastname(g, p0, Iter)
    % my_fixed_point_function_name_lastname
    % Implementa el método de punto fijo
    % Entradas:
    %   g    -> función a evaluar (handle: @(x)...)
    %   p0   -> punto inicial
    %   Iter -> número de iteraciones deseadas
    % Salida:
    %   P    -> aproximación al punto fijo después de Iter iteraciones
    
    % Vector para guardar aproximaciones
    P = zeros(1,Iter); 
    P(1) = g(p0); 
    
    fprintf('Iteración 0: p = %.6f\n', p0);
    
    for k = 2:Iter
        P(k) = g(P(k-1));
        fprintf('Iteración %d: p = %.6f\n', k-1, P(k));
    end
    
    % Retorna solo el último valor si se desea como escalar
    P = P(end);
end
