function visual_verification_name_lastname(g, a, b, p0, Iter)
% visual_verification_name_lastname
% Muestra el comportamiento gráfico del método del punto fijo.
%
% Entradas:
%   g    -> function handle, ej. @(x) 1 - (x.^3)/4
%   a    -> límite inferior del rango
%   b    -> límite superior del rango
%   p0   -> punto inicial
%   Iter -> número de iteraciones

    % Rango para graficar
    X = linspace(a,b,200);
    Y = g(X);

    figure;
    plot(X,Y,'b-','LineWidth',1.5); hold on; grid on;
    plot(X,X,'k--','LineWidth',1.2); % línea y=x
    xlabel('x'); ylabel('y');
    title('Fixed Point Iterations Visualization');
    legend('g(x)','y=x','Location','best');

    % Iteraciones gráficas
    p = p0;
    for k = 1:Iter
        % vertical: (p, p) -> (p, g(p))
        plot([p p],[p g(p)],'r-','LineWidth',1.2);

        % horizontal: (p, g(p)) -> (g(p), g(p))
        plot([p g(p)],[g(p) g(p)],'r-','LineWidth',1.2);

        % actualizar punto
        p = g(p);
    end

    % Opcional: marcar el último punto
    plot(p,g(p),'ro','MarkerFaceColor','r');

    hold off;
end
