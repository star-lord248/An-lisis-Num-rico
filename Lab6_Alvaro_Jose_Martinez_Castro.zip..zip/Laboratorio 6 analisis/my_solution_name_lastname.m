function x = my_solution_name_lastname(U,b)
    % Resuelve el sistema Ux = b donde U es triangular superior
    
    [n, ~] = size(U);
    x = zeros(n,1);   % inicializar vector solución
    
    % Sustitución hacia atrás
    for i = n:-1:1
        if U(i,i) == 0
            error('El sistema no tiene solución única (cero en la diagonal)');
        end
        x(i) = (b(i) - U(i,i+1:end) * x(i+1:end)) / U(i,i);
    end
end