function my_verification_name_lastname(A, b)
    % Verifica si el sistema Ax = b tiene solución única
    
    % Revisar si A es cuadrada
    [m, n] = size(A);
    if m ~= n
        disp('La matriz A no es cuadrada, el sistema no puede tener solución única.');
        return;
    end
    
    % Calcular determinante
    if det(A) ~= 0
        disp('El sistema tiene una solución única.');
    else
        % Si el determinante es 0, verificar consistencia
        if rank(A) == rank([A b])
            disp('El sistema tiene infinitas soluciones.');
        else
            disp('El sistema no tiene solución.');
        end
    end
end