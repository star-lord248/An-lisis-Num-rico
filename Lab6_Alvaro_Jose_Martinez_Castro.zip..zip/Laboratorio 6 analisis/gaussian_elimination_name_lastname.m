function [U, b] = gaussian_elimination_name_lastname(A,b)
    % Convierte Ax = b en Ux = b mediante eliminación Gaussiana
    % A: matriz de coeficientes
    % b: vector columna
    % U: matriz triangular superior

    [n, ~] = size(A);
    U = A;   % Copia de A para no modificar la original

    for k = 1:n-1
        % Verificar que el pivote no sea cero
        if U(k,k) == 0
            error('Cero en el pivote, necesitarías pivotear');
        end
        
        % Eliminar las entradas debajo del pivote
        for i = k+1:n
            m = U(i,k) / U(k,k);          % factor multiplicador
            U(i,k:n) = U(i,k:n) - m*U(k,k:n);
            b(i) = b(i) - m*b(k);        % actualizar también b
        end
    end
end
